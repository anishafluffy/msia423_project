# config.py

import os

# RDS database
#SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://anisha:msia_423@ebdb.cm6i6jyhr2zm.us-east-2.rds.amazonaws.com:3306/msia_db'
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://anisha:msia_423@aa1tal9q5f7mamy.cm6i6jyhr2zm.us-east-2.rds.amazonaws.com:3306/ebdb'

SQLALCHEMY_TRACK_MODIFICATIONS = False

#SECRET_KEY = 'development_key'
#SQLALCHEMY_DATABASE_URI = 'sqlite:////tmp/tracks.db'

#SQLALCHEMY_TRACK_MODIFICATIONS = False


